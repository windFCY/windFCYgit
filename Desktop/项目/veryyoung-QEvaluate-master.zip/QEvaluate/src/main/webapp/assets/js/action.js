

//////////////日历添加控件
var gMonths=new Array("一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月");
var WeekDay=new Array("日","一","二","三","四","五","六");
var strToday="今天";
var strYear="年";
var strMonth="月";
var strDay="日";
var splitChar="-";
var startYear=2000;
var endYear=2050;
var dayTdHeight=12;
var dayTdTextSize=12;
var gcNotCurMonth="#E0E0E0";
var gcRestDay="#FF0000";
var gcWorkDay="#444444";
var gcMouseOver="#79D0FF";
var gcMouseOut="#F4F4F4";
var gcToday="#444444";
var gcTodayMouseOver="#6699FF";
var gcTodayMouseOut="#79D0FF";
var gdCtrl=new Object();
var goSelectTag=new Array();
var gdCurDate=new Date();
var giYear=gdCurDate.getFullYear();
var giMonth=gdCurDate.getMonth()+1;
var giDay=gdCurDate.getDate();
function $(){var elements=new Array();for(var i=0;i<arguments.length;i++) {var element=arguments[i];if(typeof(arguments[i])=='string'){element=document.getElementById(arguments[i]);}if(arguments.length==1){return element;}elements.Push(element);}return elements;}
Array.prototype.Push=function(){var startLength=this.length;for(var i=0;i<arguments.length;i++){this[startLength+i]=arguments[i];}return this.length;}
String.prototype.HexToDec=function(){return parseInt(this,16);}
String.prototype.cleanBlank=function(){return this.isEmpty()?"":this.replace(/\s/g,"");}
function checkColor(){var color_tmp=(arguments[0]+"").replace(/\s/g,"").toUpperCase();var model_tmp1=arguments[1].toUpperCase();var model_tmp2="rgb("+arguments[1].substring(1,3).HexToDec()+","+arguments[1].substring(1,3).HexToDec()+","+arguments[1].substring(5).HexToDec()+")";model_tmp2=model_tmp2.toUpperCase();if(color_tmp==model_tmp1 ||color_tmp==model_tmp2){return true;}return false;}
function $V(){return $(arguments[0]).value;}
function fPopCalendar(evt,popCtrl,dateCtrl){evt.cancelBubble=true;gdCtrl=dateCtrl;fSetYearMon(giYear,giMonth);var point=fGetXY(popCtrl);with($("calendardiv").style){left=point.x+"px";top=(point.y+popCtrl.offsetHeight+1)+"px";visibility='visible';zindex='99';position='absolute';}$("calendardiv").focus();}
function fSetDate(iYear,iMonth,iDay){var iMonthNew=new String(iMonth);var iDayNew=new String(iDay);if(iMonthNew.length<2){iMonthNew="0"+iMonthNew;}if(iDayNew.length<2){iDayNew="0"+iDayNew;}gdCtrl.value=iYear+splitChar+iMonthNew+splitChar+iDayNew;fHideCalendar();}
function fHideCalendar(){$("calendardiv").style.visibility="hidden";for(var i=0;i<goSelectTag.length;i++){goSelectTag[i].style.visibility="visible";}goSelectTag.length=0;}
function fSetSelected(){var iOffset=0;var iYear=parseInt($("tbSelYear").value);var iMonth=parseInt($("tbSelMonth").value);var aCell=$("cellText"+arguments[0]);aCell.bgColor=gcMouseOut;with(aCell){var iDay=parseInt(innerHTML);if(checkColor(style.color,gcNotCurMonth)){iOffset=(innerHTML>10)?-1:1;}iMonth+=iOffset;if(iMonth<1){iYear--;iMonth=12;}else if(iMonth>12){iYear++;iMonth=1;}}fSetDate(iYear,iMonth,iDay);}
function Point(iX,iY){this.x=iX;this.y=iY;}
function fBuildCal(iYear,iMonth){var aMonth=new Array();for(var i=1;i<7;i++){aMonth[i]=new Array(i);}var dCalDate=new Date(iYear,iMonth-1,1);var iDayOfFirst=dCalDate.getDay();var iDaysInMonth=new Date(iYear,iMonth,0).getDate();var iOffsetLast=new Date(iYear,iMonth-1,0).getDate()-iDayOfFirst+1;var iDate=1;var iNext=1;for(var d=0;d<7;d++){aMonth[1][d]=(d<iDayOfFirst)?(iOffsetLast+d)*(-1):iDate++;}for(var w=2;w<7;w++){for(var d=0;d<7;d++){aMonth[w][d]=(iDate<=iDaysInMonth)?iDate++:(iNext++)*(-1);}}return aMonth;}
function fDrawCal(iYear,iMonth,iCellHeight,iDateTextSize){var colorTD=" bgcolor='"+gcMouseOut+"' bordercolor='"+gcMouseOut+"'";var styleTD=" valign='middle' align='center' style='height:"+iCellHeight+"px;font-weight:bolder;font-size:"+iDateTextSize+"px;";var dateCal="";dateCal+="<tr>";for(var i=0;i<7;i++){dateCal+="<td"+colorTD+styleTD+"color:#990099'>"+WeekDay[i]+"</td>";}dateCal+="</tr>";for(var w=1;w<7;w++){dateCal+="<tr>";for(var d=0;d<7;d++){var tmpid=w+""+d;dateCal+="<td"+styleTD+"cursor:pointer;' onclick='fSetSelected("+tmpid+")'>";dateCal+="<span id='cellText"+tmpid+"'></span>";dateCal+="</td>";}dateCal+="</tr>";}return dateCal;}
function fUpdateCal(iYear,iMonth){var myMonth=fBuildCal(iYear,iMonth);var i=0;for(var w=1;w<7;w++){for(var d=0;d<7;d++){with($("cellText"+w+""+d)){parentNode.bgColor=gcMouseOut;parentNode.borderColor=gcMouseOut;parentNode.onmouseover=function(){this.bgColor=gcMouseOver;};parentNode.onmouseout=function(){this.bgColor=gcMouseOut;};if(myMonth[w][d]<0){style.color=gcNotCurMonth;innerHTML=Math.abs(myMonth[w][d]);}else{style.color=((d==0)||(d==6))?gcRestDay:gcWorkDay;innerHTML=myMonth[w][d];if(iYear==giYear && iMonth==giMonth && myMonth[w][d]==giDay){style.color=gcToday;parentNode.bgColor=gcTodayMouseOut;parentNode.onmouseover=function(){this.bgColor=gcTodayMouseOver;};parentNode.onmouseout=function(){this.bgColor=gcTodayMouseOut;};}}}}}}
function fSetYearMon(iYear,iMon){$("tbSelMonth").options[iMon-1].selected=true;for(var i=0;i<$("tbSelYear").length;i++){if($("tbSelYear").options[i].value==iYear){$("tbSelYear").options[i].selected=true;}}fUpdateCal(iYear,iMon);}
function fPrevMonth(){var iMon=$("tbSelMonth").value;var iYear=$("tbSelYear").value;if(--iMon<1){iMon=12;iYear--;}fSetYearMon(iYear,iMon);}
function fNextMonth(){var iMon=$("tbSelMonth").value;var iYear=$("tbSelYear").value;if(++iMon>12){iMon=1;iYear++;}fSetYearMon(iYear,iMon);}
function fGetXY(aTag){var oTmp=aTag;var pt=new Point(0,0);do{pt.x+=oTmp.offsetLeft;pt.y+=oTmp.offsetTop;oTmp=oTmp.offsetParent;}while(oTmp.tagName.toUpperCase()!="BODY");return pt;}
function getDateDiv(){var noSelectForIE="";var noSelectForFireFox="";if(document.all){noSelectForIE="onselectstart='return false;'";}else{noSelectForFireFox="-moz-user-select:none;";}var dateDiv="";dateDiv+="<div id='calendardiv' onclick='event.cancelBubble=true' "+noSelectForIE+" style='"+noSelectForFireFox+"position:absolute;z-index:99;visibility:hidden;border:1px solid #999999;'>";dateDiv+="<table border='0' bgcolor='#E0E0E0' cellpadding='1' cellspacing='1' >";dateDiv+="<tr>";dateDiv+="<td><input type='button' id='PrevMonth' value='<' style='height:20px;width:20px;font-weight:bolder;' onclick='fPrevMonth()'>";dateDiv+="</td><td><select id='tbSelYear' style='border:1px solid;' onchange='fUpdateCal($V(\"tbSelYear\"),$V(\"tbSelMonth\"))'>";for(var i=startYear;i<endYear;i++){dateDiv+="<option value='"+i+"'>"+i+strYear+"</option>";}dateDiv+="</select></td><td>";dateDiv+="<select id='tbSelMonth' style='border:1px solid;' onchange='fUpdateCal($V(\"tbSelYear\"),$V(\"tbSelMonth\"))'>";for(var i=0;i<12;i++){dateDiv+="<option value='"+(i+1)+"'>"+gMonths[i]+"</option>";}dateDiv+="</select></td><td>";dateDiv+="<input type='button' id='NextMonth' value='>' style='height:20px;width:20px;font-weight:bolder;' onclick='fNextMonth()'>";dateDiv+="</td>";dateDiv+="</tr><tr>";dateDiv+="<td align='center' colspan='4'>";dateDiv+="<div style='background-color:#cccccc'><table width='100%' border='0' cellpadding='3' cellspacing='1'>";dateDiv+=fDrawCal(giYear,giMonth,dayTdHeight,dayTdTextSize);dateDiv+="</table></div>";dateDiv+="</td>";dateDiv+="</tr><tr><td align='center' colspan='4' nowrap>";dateDiv+="<span style='cursor:pointer;font-weight:bolder;' onclick='fSetDate(giYear,giMonth,giDay)' onmouseover='this.style.color=\""+gcMouseOver+"\"' onmouseout='this.style.color=\"#000000\"'>"+strToday+":"+giYear+strYear+giMonth+strMonth+giDay+strDay+"</span>";dateDiv+="</tr></tr>";dateDiv+="</table></div>";return dateDiv;}
with(document){onclick=fHideCalendar;write(getDateDiv());}


////// 添加团队
function addTeamw(evt)
{

    var e = evt||window.event;
    var target =  e.srcElement || e.target;
    var div = target.parentNode;

    var index=div.getElementsByTagName("div").length;
    var fDiv=div.getElementsByTagName("div").item(0);//复刻第一个div

    var newDiv=document.createElement("div");
    newDiv.setAttribute("name",fDiv.getAttribute("id")+"_"+index);
    newDiv.setAttribute("id",fDiv.getAttribute("id"));

    var fChild=fDiv.children;
    for(var i=0;i<=fChild.length;i++)
    {
        var  now=document.createElement(fChild.item(i).nodeName);

        if(fChild.item(i).nodeName=="BR"||fChild.item(i).type=="button")break;
        if(fChild.item(i).nodeName=="P")
        {
            now.innerText=fChild.item(i).innerText;
        }
        if(fChild.item(i).nodeName=="LABEL")
        {
            now.setAttribute("name",fChild.item(i).getAttribute("name"));
            now.innerText=fChild.item(i).innerText;
        }
        if(fChild.item(i).nodeName=="INPUT")
        {
            var id=fChild.item(i).getAttribute("id");
            now.setAttribute("name",id+"_"+index);
            now.setAttribute("id",id);
            now.setAttribute("type","text");
        }
        newDiv.appendChild(now);
    }
    var buttonList = fDiv.getElementsByTagName("input");
    for(var i=0;i<buttonList.length;i++)
    {
        if(buttonList.item(i).type=="button")
        {
            var now = document.createElement("INPUT")
            now.setAttribute("name",buttonList.item(i).getAttribute("name"));
            now.setAttribute("id",buttonList.item(i).getAttribute("id"));
            now.setAttribute("type",buttonList.item(i).getAttribute("type"));
            now.setAttribute("onclick",buttonList.item(i).getAttribute("onclick"));
            now.setAttribute("value",buttonList.item(i).getAttribute("value"));
            newDiv.appendChild(now);
        }
    }
    div.insertBefore(newDiv,target);
}

//////////////////增加一行学号，姓名控件
function addNewLine(evt)
{
    var e = evt||window.event;
    var target =  e.srcElement || e.target;///////////target既是按钮对象，新建的元素均查到target之前，使用insertbefore（）插入
    var   div   =target.parentNode;
    //////检验最后一行的text是否为空，若不为空可添加新行，否则不可添加新行
    var textList = div.getElementsByTagName("input");
		for(var i=0;i<textList.length;i++)
		{
			if(textList[i].type=="text"&&textList[i].value=="")
				return ;
		}
    ///////////////////要插入的元素都插入到其前面
    var index=textList.length;
    ///////////////找到最后一text，在其后面添加
    var   br=document.createElement("br");//换行
    div.insertBefore(br,target);
    var child=div.children;
    for (var i=0;i<=child.length;i++)
    {
        var now=document.createElement(child.item(i).nodeName);
        if(child.item(i).nodeName=="P")continue;
        if(child.item(i).nodeName=="BR")break;
        if(child.item(i).nodeName=="LABEL")
        {
            now.innerText=child.item(i).innerText;
            now.setAttribute("name",index);
        }
        if(child.item(i).nodeName=="INPUT")
        {
            var id=child.item(i).getAttribute("id");
            now.setAttribute("name",id+"_"+index);
            now.setAttribute("id",id);
            now.setAttribute("type","text");
        }
        div.insertBefore(now,target);
    }
}

/////////////删除一行学号，姓名控件
function removeLine(evt)
{
    var e = evt || window.event;
    var target = e.srcElement || e.target;
    var   div   =target.parentNode;
    var br = div.getElementsByTagName("BR");
    var child=div.children;
    if(br.length>0)
    {
        var i;
        for(i=child.length-1;child.item(i).nodeName!="BR";i--)
        {
            if(child.item(i).type=="text"||child.item(i).nodeName=="LABEL")
            {
                div.removeChild(child.item(i));
            }
        }
        div.removeChild(child.item(i));
    }
}
/////////////////去掉空白节点的方法
function filterWhiteNode(node)
{
    var ret = [];
    for(var i=0;i<node.length;i++)
    {
        if(node[i].nodType==3&&/^\s+$/.test(node[i].nodeValue))
        {
            //alert("一个");
            continue;
        }
        else
        {
            ret.Push(node[i]);
        }

    }
    return ret;
}


/////////////////页面加载，labnum等默认隐藏
window.onload = function(){

    var labNum = document.getElementById("labNum");
    labNum.style.visibility = "hidden";


}

/////////////表单提交时对验证输入
function checkData(evt)
{

    /////检验学号是否合法,数字且长度10位
    var pattern = /^\d{10}$/;
    var textNum = document.getElementById("declarer_id");
    var labNum = document.getElementById("labNum");
    var form = document.getElementById("form");
    var text = textNum.value;

    var e = evt||window.event;
    //////////////////去掉字符串头部尾部
    text = text.replace(/^(\s|\xA0)+|(\s|\xA0)+$/g, '');
    // alert(e);
    if(!pattern.test(text))/////若输入不满足规范显示提示框，不提交
    {
        labNum.style.visibility="visible";
        form.submit = preDef(e);/////使提交表单无效
    }
    else//////否则隐藏提示框，提交表单
        labNum.style.visibility="hidden";
}

//////////////////取消默认行为方法
function preDef(e)
{
    if(e.preventDefault)////w3c

    {e.preventDefault();}
    else////兼容ie

    {e.returnValue = false;	 }
}

///////添加一项查寝结果
function addRoomCheckRest(evt){
    var e = evt||window.event;
    var target =  e.srcElement || e.target;///////////target既是按钮对象，新建的元素均查到target之前，使用insertbefore（）插入
    var   div   =target.parentNode;
    //////检验最后一行的text是否为空，若不为空可添加新行，否则不可添加新行
    var textList = div.getElementsByTagName("input");
    for(var i=0;i<textList.length;i++)
    {
        if(textList[i].type=="text"&&textList[i].value=="")
            return ;
    }
    ///////////////////要插入的元素都插入到其前面
    var index=textList.length;
    ///////////////找到最后一text，在其后面添加
    var   br=document.createElement("br");//换行
    div.insertBefore(br,target);
    var child=div.children;
    for (var i=1;i<=child.length;i++)
    {
        var now=document.createElement(child.item(i).nodeName);
        if(child.item(i).nodeName=="BR")break;
        if(child.item(i).nodeName=="LABEL")
        {
            now.innerText=child.item(i).innerText;
            now.setAttribute("name",index);
        }
        if(child.item(i).nodeName=="INPUT")
        {
            var id=child.item(i).getAttribute("id");
            now.setAttribute("name",id+"_"+index);
            now.setAttribute("id",id);
            now.setAttribute("type","text");
        }
        if(child.item(i).nodeName=="SELECT"){
            var id=child.item(i).getAttribute("id");
            now.setAttribute("name",id+"_"+index);
            now.setAttribute("id",id);
            var optionTextArr = new Array("优","良","中","及格","不及格");

            for(var j = 0 ;j<5; j++){
                var option = document.createElement("OPTION");
                option.innerText = optionTextArr[j];
                now.appendChild(option);
            }

        }
        div.insertBefore(now,target);
    }
}